package com.hydromex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private data class River(val name:String,val basin:String,val states:String,val length:String,val note:String,val points:List<GeoPoint>)
private val rivers = listOf(
    River("Río Bravo","Río Bravo","Chihuahua, Coahuila, Nuevo León y Tamaulipas","≈ 3,000 km (sistema completo)","Río fronterizo del norte de México.", listOf(GeoPoint(31.75,-106.48),GeoPoint(29.5,-104.5),GeoPoint(28.7,-102.1),GeoPoint(27.5,-100.2),GeoPoint(26.1,-99.2),GeoPoint(25.9,-97.5))),
    River("Río Colorado","Río Colorado","Baja California y Sonora","≈ 2,330 km (sistema completo)","Sistema fluvial que llega al Alto Golfo de California.",listOf(GeoPoint(32.72,-114.8),GeoPoint(32.4,-114.1),GeoPoint(31.9,-113.8),GeoPoint(31.5,-114.0))),
    River("Lerma–Santiago","Lerma–Santiago","Centro-occidente de México","Sistema fluvial de gran extensión","Conecta la cuenca del Lerma con el río Santiago.",listOf(GeoPoint(19.9,-100.7),GeoPoint(20.2,-101.3),GeoPoint(20.5,-102.2),GeoPoint(20.7,-103.4),GeoPoint(21.0,-104.0),GeoPoint(21.5,-105.2))),
    River("Río Balsas","Río Balsas","Guerrero, Michoacán, Puebla y otros estados","≈ 770 km","Importante sistema fluvial del sur-centro.",listOf(GeoPoint(18.1,-98.2),GeoPoint(18.0,-99.0),GeoPoint(17.9,-100.0),GeoPoint(17.8,-101.2),GeoPoint(17.9,-102.1))),
    River("Río Papaloapan","Papaloapan","Oaxaca y Veracruz","≈ 354 km (cauce principal)","Cuenca con amplias planicies y antecedentes de inundaciones.",listOf(GeoPoint(17.7,-96.8),GeoPoint(18.0,-96.2),GeoPoint(18.2,-95.9),GeoPoint(18.4,-95.7))),
    River("Grijalva–Usumacinta","Grijalva–Usumacinta","Chiapas y Tabasco","Sistema fluvial transfronterizo","Sistema de gran relevancia hidrológica para Chiapas y Tabasco.",listOf(GeoPoint(16.7,-92.6),GeoPoint(17.1,-92.8),GeoPoint(17.5,-92.9),GeoPoint(17.9,-92.8),GeoPoint(18.2,-92.7),GeoPoint(18.4,-92.6)))
)

private val Navy = Color(0xFF07131F)
private val Panel = Color(0xFF102536)
private val Cyan = Color(0xFF46D4E5)
private val Muted = Color(0xFF91A8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContent { HydromexApp() }
    }
}

@Composable
fun HydromexApp() {
    var dark by remember { mutableStateOf(true) }
    var page by remember { mutableStateOf("Inicio") }
    var selected by remember { mutableStateOf(rivers.last()) }
    var search by remember { mutableStateOf("") }
    var rain by remember { mutableStateOf("Busca una localidad para consultar lluvia.") }
    var rainValue by remember { mutableStateOf("--") }
    var probability by remember { mutableStateOf("--") }
    var place by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val bg = if(dark) Navy else Color(0xFFF2F6F8)
    val surface = if(dark) Panel else Color.White
    val fg = if(dark) Color(0xFFE7F1F7) else Color(0xFF142B3A)
    val muted = if(dark) Muted else Color(0xFF607888)
    MaterialTheme(colorScheme = if(dark) darkColorScheme(primary=Cyan,background=bg,surface=surface,onSurface=fg) else lightColorScheme(primary=Color(0xFF087D91),background=bg,surface=surface,onSurface=fg)) {
        Scaffold(containerColor=bg, bottomBar={
            NavigationBar(containerColor=surface) {
                listOf("Inicio","Mapa","Ríos","Lluvias","Riesgo").forEach { item ->
                    val icon = when(item){"Inicio"->Icons.Default.Dashboard;"Mapa"->Icons.Default.Map;"Ríos"->Icons.Default.Water;"Lluvias"->Icons.Default.Cloud;"Riesgo"->Icons.Default.Warning;else->Icons.Default.Info}
                    NavigationBarItem(selected=page==item,onClick={page=item},icon={Icon(icon,null)},label={Text(item,fontSize=10.sp)})
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().background(surface).padding(horizontal=18.dp, vertical=14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("≈  HYDROMEX",fontSize=20.sp,fontWeight=FontWeight.Black,color=fg,letterSpacing=1.5.sp)
                        Text("MONITOREO HÍDRICO DE MÉXICO",fontSize=9.sp,color=muted,letterSpacing=1.sp)
                    }
                    IconButton(onClick={dark=!dark}) { Icon(if(dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Cambiar tema", tint=fg) }
                }
                when(page) {
                    "Inicio" -> Dashboard(fg,muted,surface,{page="Mapa"},{page="Ríos"})
                    "Mapa" -> MapScreen(dark,fg,muted,surface,{selected=it;page="Ríos"})
                    "Ríos" -> RiversScreen(fg,muted,surface,selected,{selected=it})
                    "Lluvias" -> RainScreen(fg,muted,surface,search,{search=it},rain,rainValue,probability,place,
                        { q -> scope.launch { val result=lookupAndWeather(q); rain=result.message;rainValue=result.amount;probability=result.prob;place=result.place } })
                    else -> RiskScreen(fg,muted,surface)
                }
            }
        }
    }
}

@Composable
fun Dashboard(fg:Color,muted:Color,surface:Color,onMap:()->Unit,onRivers:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Centro de monitoreo",fontSize=24.sp,fontWeight=FontWeight.Bold,color=fg);Text("Resumen de la plataforma · México",color=muted,fontSize=12.sp) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Stat("6","Ríos en catálogo",surface,fg,muted,Modifier.weight(1f));Stat("0","Estaciones oficiales",surface,fg,muted,Modifier.weight(1f)) } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Stat("--","Alertas verificadas",surface,fg,muted,Modifier.weight(1f));Stat("--","Riesgo nacional",surface,fg,muted,Modifier.weight(1f)) } }
        item { Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) {
            Text("Estado de los datos",fontWeight=FontWeight.Bold,color=fg);Spacer(Modifier.height(7.dp))
            Text("Esta primera versión incluye cartografía base, catálogo descriptivo y consulta de lluvia por localidad. Los niveles de ríos y alertas oficiales aún no están conectados.",color=muted,fontSize=12.sp)
            Text("Los datos de riesgo no deben utilizarse para decisiones de emergencia.",color=Color(0xFFE8B75B),fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
        } } }
        item { Button(onClick=onMap,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Map,null);Spacer(Modifier.width(8.dp));Text("Explorar mapa") } }
        item { OutlinedButton(onClick=onRivers,modifier=Modifier.fillMaxWidth()) { Text("Consultar catálogo de ríos") } }
        item { Text("Módulos disponibles",fontWeight=FontWeight.Bold,color=fg,fontSize=16.sp) }
        items(listOf("Mapa interactivo · OpenStreetMap","Catálogo de seis sistemas fluviales","Pronóstico de lluvia · Open-Meteo","Modo claro y modo oscuro")) { Text("• $it",color=muted,fontSize=13.sp) }
    }
}

@Composable
fun Stat(value:String,label:String,surface:Color,fg:Color,muted:Color,modifier:Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(13.dp)) { Text(label,color=muted,fontSize=10.sp);Text(value,color=fg,fontSize=23.sp,fontWeight=FontWeight.Bold) }
    }
}

@Composable
fun MapScreen(dark:Boolean,fg:Color,muted:Color,surface:Color,onSelect:(River)->Unit) {
    var showRivers by remember { mutableStateOf(true) }
    var showPoints by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Mapa de México",fontSize=21.sp,fontWeight=FontWeight.Bold,color=fg)
        Text("Ríos esquemáticos · selecciona un trazo para abrir su ficha",fontSize=11.sp,color=muted)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(vertical=8.dp)) {
            FilterChip(selected=showRivers,onClick={showRivers=!showRivers},label={Text("Ríos")})
            FilterChip(selected=showPoints,onClick={showPoints=!showPoints},label={Text("Referencias")})
        }
        AndroidView(factory={ctx ->
            MapView(ctx).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(true)
                controller.setZoom(4.5)
                controller.setCenter(GeoPoint(23.6,-102.5))
                if(showRivers) rivers.forEach { r ->
                    val line=Polyline()
                    line.setPoints(r.points)
                    line.outlinePaint.color=android.graphics.Color.rgb(35,190,215)
                    line.outlinePaint.strokeWidth=7f
                    overlays.add(line)
                }
                invalidate()
            }
        },update={ map ->
            map.overlays.removeAll { it is Polyline }
            if(showRivers) rivers.forEach { r ->
                val line=Polyline().apply {
                    setPoints(r.points)
                    outlinePaint.color=android.graphics.Color.rgb(35,190,215)
                    outlinePaint.strokeWidth=7f
                    setOnClickListener { _,_,_ -> onSelect(r); true }
                }
                map.overlays.add(line)
            }
            map.invalidate()
        },modifier=Modifier.fillMaxWidth().weight(1f))
        Text("Cartografía base © OpenStreetMap. Trazos fluviales ilustrativos, no oficiales.",fontSize=10.sp,color=muted,modifier=Modifier.padding(5.dp))
        LazyColumn(Modifier.heightIn(max=118.dp)) { items(rivers) { r -> TextButton(onClick={onSelect(r)}) { Text(r.name,color=fg) } } }
    }
}

@Composable
fun RiversScreen(fg:Color,muted:Color,surface:Color,selected:River,onSelect:(River)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { Text("Catálogo de ríos",fontSize=22.sp,fontWeight=FontWeight.Bold,color=fg);Text("Información geográfica general",color=muted,fontSize=12.sp) }
        items(rivers) { r ->
            Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(13.dp),modifier=Modifier.fillMaxWidth().clickable{onSelect(r)}) {
                Column(Modifier.padding(14.dp)) {
                    Text(r.name,fontWeight=FontWeight.Bold,color=fg,fontSize=15.sp)
                    Text("${r.basin} · ${r.states}",fontSize=11.sp,color=muted)
                    if(r==selected) { Spacer(Modifier.height(8.dp));Text("Longitud: ${r.length}",color=fg,fontSize=12.sp);Text(r.note,color=muted,fontSize=12.sp);Text("Nivel actual: sin estación oficial conectada",color=Color(0xFFE8B75B),fontSize=11.sp) }
                }
            }
        }
        item { Text("Toca un río para desplegar su ficha.",color=muted,fontSize=11.sp) }
    }
}

@Composable
fun RainScreen(fg:Color,muted:Color,surface:Color,search:String,onSearch:(String)->Unit,message:String,amount:String,prob:String,place:String,onLookup:(String)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Lluvias y pronóstico",fontSize=22.sp,fontWeight=FontWeight.Bold,color=fg)
        Text("Busca una localidad de México para consultar precipitación pronosticada.",color=muted,fontSize=12.sp)
        OutlinedTextField(value=search,onValueChange=onSearch,label={Text("Municipio o localidad")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Button(onClick = { onLookup(search) }, enabled = search.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Consultar pronóstico") }
        Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(if(place.isBlank()) "Resultado" else place,color=fg,fontWeight=FontWeight.Bold)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) { Text("Lluvia próximas 24 h",color=muted,fontSize=10.sp);Text(amount,color=fg,fontSize=23.sp,fontWeight=FontWeight.Bold) }
                    Column(Modifier.weight(1f)) { Text("Probabilidad máxima",color=muted,fontSize=10.sp);Text(prob,color=fg,fontSize=23.sp,fontWeight=FontWeight.Bold) }
                }
                Text(message,color=muted,fontSize=11.sp)
            }
        }
        Text("Fuente: Open-Meteo. Pronóstico orientativo; no equivale a una alerta oficial del SMN.",color=muted,fontSize=10.sp)
    }
}

@Composable
fun RiskScreen(fg:Color,muted:Color,surface:Color) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Riesgo de inundación",fontSize=22.sp,fontWeight=FontWeight.Bold,color=fg);Text("Módulo preparado para integrar datos oficiales.",color=muted,fontSize=12.sp) }
        item { Card(colors=CardDefaults.cardColors(containerColor=surface),shape=RoundedCornerShape(14.dp)) { Column(Modifier.padding(16.dp)) {
            Text("Sin evaluación operativa",fontWeight=FontWeight.Bold,color=Color(0xFFE8B75B),fontSize=16.sp)
            Text("Todavía no hay estaciones hidrométricas, umbrales locales ni capas oficiales de inundación conectadas. Por seguridad, no se asigna un nivel de peligro.",color=muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
        } } }
        items(listOf("Nivel de río y umbrales de cada estación","Tendencia de subida o descenso","Lluvia observada y pronosticada","Topografía y zonas inundables verificadas","Avisos de Protección Civil")) { item ->
            Card(colors=CardDefaults.cardColors(containerColor=surface)) { Text("• $item",color=fg,modifier=Modifier.padding(13.dp),fontSize=12.sp) }
        }
    }
}

private data class WeatherResult(val message:String,val amount:String,val prob:String,val place:String)
private suspend fun lookupAndWeather(query:String):WeatherResult = withContext(Dispatchers.IO) {
    try {
        val encoded=URLEncoder.encode("$query, México","UTF-8")
        val geocode=URL("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=es&format=json")
        val geo=JSONObject(geocode.readText())
        val results=geo.optJSONArray("results") ?: return@withContext WeatherResult("No se encontró la localidad.","--","--","")
        if(results.length()==0) return@withContext WeatherResult("No se encontró la localidad.","--","--","")
        val item=results.getJSONObject(0)
        val lat=item.getDouble("latitude");val lon=item.getDouble("longitude")
        val label=item.optString("name")
        val weather=JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=precipitation,precipitation_probability&forecast_days=2&timezone=auto").readText())
        val hourly=weather.getJSONObject("hourly")
        val times=hourly.getJSONArray("time");val rain=hourly.getJSONArray("precipitation");val probs=hourly.getJSONArray("precipitation_probability")
        var sum=0.0;var max=0
        for(i in 0 until times.length()) {
            val t=times.getString(i)
            if(i<24) { sum+=rain.optDouble(i,0.0);max=maxOf(max,probs.optInt(i,0)) }
        }
        WeatherResult("Pronóstico orientativo de Open-Meteo. No es una alerta oficial.",String.format("%.1f mm",sum),"$max%",label)
    } catch(e:Exception) { WeatherResult("No fue posible consultar el servicio. Revisa tu conexión.","--","--","") }
}
private fun URL.readText():String {
    val c=openConnection() as HttpURLConnection
    c.connectTimeout=12000;c.readTimeout=12000
    return try { c.inputStream.bufferedReader().use{it.readText()} } finally { c.disconnect() }
}
