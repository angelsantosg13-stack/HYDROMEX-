# HYDROMEX Android — primera versión

Proyecto Android nativo en Kotlin + Jetpack Compose.

## Compilar APK desde GitHub (solo necesitas un teléfono)
1. Crea un repositorio nuevo en GitHub llamado `HYDROMEX` y déjalo **Public** o **Private**.
2. Sube el contenido completo de esta carpeta a la rama `main`, conservando la carpeta `.github/workflows`.
3. Abre la pestaña **Actions** del repositorio. Si GitHub pide habilitar workflows, acepta.
4. Selecciona **Build HYDROMEX APK** y pulsa **Run workflow**. También se ejecuta automáticamente al subir cambios a `main`.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto **HYDROMEX-debug-apk**. Descomprime el ZIP descargado: ahí estará `app-debug.apk`.
6. Abre el APK en Android y autoriza la instalación desde esa fuente si el sistema lo solicita.

El workflow instala Gradle 8.9, JDK 17 y el SDK de Android en GitHub Actions. No necesitas Android Studio ni Gradle Wrapper en tu teléfono.

## Abrir en Android Studio
Abre esta carpeta como proyecto y espera la sincronización de Gradle.

## Incluye
- Navegación inferior: Inicio, Mapa, Ríos, Lluvias y Riesgo.
- Tema oscuro/claro con selector.
- Mapa OpenStreetMap mediante osmdroid.
- Trazos esquemáticos de seis ríos/sistemas fluviales.
- Fichas descriptivas.
- Consulta de precipitación pronosticada por localidad mediante Open-Meteo.
- Permiso de internet.

## Limitaciones y seguridad
Los trazos fluviales son esquemáticos y solo ilustrativos. Esta versión no se conecta a niveles hidrométricos oficiales, alertas de CONAGUA/SMN, atlas oficiales ni evaluación operativa de inundaciones. No usar para decisiones de emergencia. La consulta meteorológica depende de internet.

## Siguientes pasos recomendados
Integrar geometrías hidrográficas oficiales, estaciones y umbrales de CONAGUA, avisos SMN/Protección Civil, base geoespacial y backend seguro. Agregar caché, pruebas, manejo de cuotas, atribución y política de privacidad antes de publicar.
